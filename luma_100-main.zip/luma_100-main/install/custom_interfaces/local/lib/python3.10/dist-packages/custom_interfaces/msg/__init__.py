from custom_interfaces.msg._navigation_report import NavigationReport  # noqa: F401
