// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:srv/MsgRequest.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__DETAIL__MSG_REQUEST__BUILDER_HPP_
#define CUSTOM_INTERFACES__SRV__DETAIL__MSG_REQUEST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/srv/detail/msg_request__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_MsgRequest_Request_ready_to_transmit
{
public:
  Init_MsgRequest_Request_ready_to_transmit()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interfaces::srv::MsgRequest_Request ready_to_transmit(::custom_interfaces::srv::MsgRequest_Request::_ready_to_transmit_type arg)
  {
    msg_.ready_to_transmit = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::MsgRequest_Request>()
{
  return custom_interfaces::srv::builder::Init_MsgRequest_Request_ready_to_transmit();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_MsgRequest_Response_battery_ok
{
public:
  explicit Init_MsgRequest_Response_battery_ok(::custom_interfaces::srv::MsgRequest_Response & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::MsgRequest_Response battery_ok(::custom_interfaces::srv::MsgRequest_Response::_battery_ok_type arg)
  {
    msg_.battery_ok = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Response msg_;
};

class Init_MsgRequest_Response_veh_class
{
public:
  explicit Init_MsgRequest_Response_veh_class(::custom_interfaces::srv::MsgRequest_Response & msg)
  : msg_(msg)
  {}
  Init_MsgRequest_Response_battery_ok veh_class(::custom_interfaces::srv::MsgRequest_Response::_veh_class_type arg)
  {
    msg_.veh_class = std::move(arg);
    return Init_MsgRequest_Response_battery_ok(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Response msg_;
};

class Init_MsgRequest_Response_z
{
public:
  explicit Init_MsgRequest_Response_z(::custom_interfaces::srv::MsgRequest_Response & msg)
  : msg_(msg)
  {}
  Init_MsgRequest_Response_veh_class z(::custom_interfaces::srv::MsgRequest_Response::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_MsgRequest_Response_veh_class(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Response msg_;
};

class Init_MsgRequest_Response_y
{
public:
  explicit Init_MsgRequest_Response_y(::custom_interfaces::srv::MsgRequest_Response & msg)
  : msg_(msg)
  {}
  Init_MsgRequest_Response_z y(::custom_interfaces::srv::MsgRequest_Response::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_MsgRequest_Response_z(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Response msg_;
};

class Init_MsgRequest_Response_x
{
public:
  Init_MsgRequest_Response_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MsgRequest_Response_y x(::custom_interfaces::srv::MsgRequest_Response::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_MsgRequest_Response_y(msg_);
  }

private:
  ::custom_interfaces::srv::MsgRequest_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::MsgRequest_Response>()
{
  return custom_interfaces::srv::builder::Init_MsgRequest_Response_x();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__SRV__DETAIL__MSG_REQUEST__BUILDER_HPP_
