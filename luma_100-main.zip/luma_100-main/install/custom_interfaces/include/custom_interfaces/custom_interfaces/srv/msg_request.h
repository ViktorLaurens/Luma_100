// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:srv/MsgRequest.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__MSG_REQUEST_H_
#define CUSTOM_INTERFACES__SRV__MSG_REQUEST_H_

#include "custom_interfaces/srv/detail/msg_request__struct.h"
#include "custom_interfaces/srv/detail/msg_request__functions.h"
#include "custom_interfaces/srv/detail/msg_request__type_support.h"

#endif  // CUSTOM_INTERFACES__SRV__MSG_REQUEST_H_
