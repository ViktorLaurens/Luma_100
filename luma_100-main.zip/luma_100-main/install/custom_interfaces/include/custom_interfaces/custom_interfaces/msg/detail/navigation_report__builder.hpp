// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:msg/NavigationReport.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__BUILDER_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/msg/detail/navigation_report__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace msg
{

namespace builder
{

class Init_NavigationReport_battery_ok
{
public:
  explicit Init_NavigationReport_battery_ok(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::msg::NavigationReport battery_ok(::custom_interfaces::msg::NavigationReport::_battery_ok_type arg)
  {
    msg_.battery_ok = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_veh_class
{
public:
  explicit Init_NavigationReport_veh_class(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  Init_NavigationReport_battery_ok veh_class(::custom_interfaces::msg::NavigationReport::_veh_class_type arg)
  {
    msg_.veh_class = std::move(arg);
    return Init_NavigationReport_battery_ok(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_z
{
public:
  explicit Init_NavigationReport_z(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  Init_NavigationReport_veh_class z(::custom_interfaces::msg::NavigationReport::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_NavigationReport_veh_class(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_y
{
public:
  explicit Init_NavigationReport_y(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  Init_NavigationReport_z y(::custom_interfaces::msg::NavigationReport::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_NavigationReport_z(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_x
{
public:
  explicit Init_NavigationReport_x(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  Init_NavigationReport_y x(::custom_interfaces::msg::NavigationReport::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_NavigationReport_y(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_ack_ids
{
public:
  explicit Init_NavigationReport_ack_ids(::custom_interfaces::msg::NavigationReport & msg)
  : msg_(msg)
  {}
  Init_NavigationReport_x ack_ids(::custom_interfaces::msg::NavigationReport::_ack_ids_type arg)
  {
    msg_.ack_ids = std::move(arg);
    return Init_NavigationReport_x(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

class Init_NavigationReport_message_id
{
public:
  Init_NavigationReport_message_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NavigationReport_ack_ids message_id(::custom_interfaces::msg::NavigationReport::_message_id_type arg)
  {
    msg_.message_id = std::move(arg);
    return Init_NavigationReport_ack_ids(msg_);
  }

private:
  ::custom_interfaces::msg::NavigationReport msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::msg::NavigationReport>()
{
  return custom_interfaces::msg::builder::Init_NavigationReport_message_id();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__BUILDER_HPP_
