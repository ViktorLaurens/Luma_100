// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custom_interfaces:msg/NavigationReport.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_H_
#define CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'ack_ids'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/NavigationReport in the package custom_interfaces.
typedef struct custom_interfaces__msg__NavigationReport
{
  uint16_t message_id;
  rosidl_runtime_c__int16__Sequence ack_ids;
  double x;
  double y;
  double z;
  uint8_t veh_class;
  bool battery_ok;
} custom_interfaces__msg__NavigationReport;

// Struct for a sequence of custom_interfaces__msg__NavigationReport.
typedef struct custom_interfaces__msg__NavigationReport__Sequence
{
  custom_interfaces__msg__NavigationReport * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_interfaces__msg__NavigationReport__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_H_
