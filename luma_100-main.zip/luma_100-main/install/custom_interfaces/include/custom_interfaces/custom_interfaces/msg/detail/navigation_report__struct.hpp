// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from custom_interfaces:msg/NavigationReport.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__custom_interfaces__msg__NavigationReport __attribute__((deprecated))
#else
# define DEPRECATED__custom_interfaces__msg__NavigationReport __declspec(deprecated)
#endif

namespace custom_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct NavigationReport_
{
  using Type = NavigationReport_<ContainerAllocator>;

  explicit NavigationReport_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->message_id = 0;
      this->x = 0.0;
      this->y = 0.0;
      this->z = 0.0;
      this->veh_class = 0;
      this->battery_ok = false;
    }
  }

  explicit NavigationReport_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->message_id = 0;
      this->x = 0.0;
      this->y = 0.0;
      this->z = 0.0;
      this->veh_class = 0;
      this->battery_ok = false;
    }
  }

  // field types and members
  using _message_id_type =
    uint16_t;
  _message_id_type message_id;
  using _ack_ids_type =
    std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>>;
  _ack_ids_type ack_ids;
  using _x_type =
    double;
  _x_type x;
  using _y_type =
    double;
  _y_type y;
  using _z_type =
    double;
  _z_type z;
  using _veh_class_type =
    uint8_t;
  _veh_class_type veh_class;
  using _battery_ok_type =
    bool;
  _battery_ok_type battery_ok;

  // setters for named parameter idiom
  Type & set__message_id(
    const uint16_t & _arg)
  {
    this->message_id = _arg;
    return *this;
  }
  Type & set__ack_ids(
    const std::vector<int16_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int16_t>> & _arg)
  {
    this->ack_ids = _arg;
    return *this;
  }
  Type & set__x(
    const double & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const double & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__z(
    const double & _arg)
  {
    this->z = _arg;
    return *this;
  }
  Type & set__veh_class(
    const uint8_t & _arg)
  {
    this->veh_class = _arg;
    return *this;
  }
  Type & set__battery_ok(
    const bool & _arg)
  {
    this->battery_ok = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    custom_interfaces::msg::NavigationReport_<ContainerAllocator> *;
  using ConstRawPtr =
    const custom_interfaces::msg::NavigationReport_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      custom_interfaces::msg::NavigationReport_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      custom_interfaces::msg::NavigationReport_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__custom_interfaces__msg__NavigationReport
    std::shared_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__custom_interfaces__msg__NavigationReport
    std::shared_ptr<custom_interfaces::msg::NavigationReport_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NavigationReport_ & other) const
  {
    if (this->message_id != other.message_id) {
      return false;
    }
    if (this->ack_ids != other.ack_ids) {
      return false;
    }
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->z != other.z) {
      return false;
    }
    if (this->veh_class != other.veh_class) {
      return false;
    }
    if (this->battery_ok != other.battery_ok) {
      return false;
    }
    return true;
  }
  bool operator!=(const NavigationReport_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NavigationReport_

// alias to use template instance with default allocator
using NavigationReport =
  custom_interfaces::msg::NavigationReport_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NAVIGATION_REPORT__STRUCT_HPP_
