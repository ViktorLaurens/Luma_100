// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/NavigationReport.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__NAVIGATION_REPORT_H_
#define CUSTOM_INTERFACES__MSG__NAVIGATION_REPORT_H_

#include "custom_interfaces/msg/detail/navigation_report__struct.h"
#include "custom_interfaces/msg/detail/navigation_report__functions.h"
#include "custom_interfaces/msg/detail/navigation_report__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__NAVIGATION_REPORT_H_
